  #Problem Statement(Parking lot)
  I own a multi-storey parking lot that can hold up to 'n' cars at any given point in time.
  Each slot is given a number starting at 1 increasing with increasing distance from the
  entry point in steps of one. I want to create an automated ticketing system that
  allows my customers to use my parking lot without human intervention.
  When a car enters my parking lot, I want to have a ticket issued to the driver. The
  ticket issuing process includes us documenting the registration number (number
  plate) and the colour of the car and allocating an available parking slot to the car
  before actually handing over a ticket to the driver (we assume that our customers are
  nice enough to always park in the slots allocated to them). The customer should be
  allocated a parking slot which is nearest to the entry. At the exit the customer returns
  the ticket which then marks the slot they were using as being available.
  Due to government regulation, the system should provide me with the ability to find
  out :
  
  1. Registration numbers of all cars of a particular colour.
  
  2.Slot number in which a car with a given registration number is parked.
  
  3.Slot numbers of all slots where a car of a particular colour is parked.
  
  ####Project Requirements
       
       Latest version of JDK.
       Latest version of maven. 
       
 
  ##### Install dependencies compile and run 
     $ bin/setup
     
  ## Example for File input 
  To run the program 
  
      $ bin/parking_lot file_inputs.txt   
      
  ### Input file 
     create_parking_lot 6
     park KA-01-HH-1234 White
     park KA-01-HH-9999 White
     park KA-01-BB-0001 Black
     park KA-01-HH-7777 Red
     park KA-01-HH-2701 Blue
     park KA-01-HH-3141 Black
     leave 4
     status
     park KA-01-P-333 White
     park DL-12-AA-9999 White
     registration_numbers_for_cars_with_colour White
     slot_numbers_for_cars_with_colour White
     slot_number_for_registration_number KA-01-HH-3141
     slot_number_for_registration_number MH-04-AY-1111 
  
  ### output
     Created a parking lot with 6 slots
     Allocated slot number: 1
     Allocated slot number: 2
     Allocated slot number: 3
     Allocated slot number: 4
     Allocated slot number: 5
     Allocated slot number: 6
     Slot number 4 is free
     Slot No. Registration No Colour
     1 KA-01-HH-1234 White
     2 KA-01-HH-9999 White
     3 KA-01-BB-0001 Black
     5 KA-01-HH-2701 Blue
     6 KA-01-HH-3141 Black
     Allocated slot number: 4
     Sorry, parking lot is full
     KA-01-HH-1234, KA-01-HH-9999, KA-01-P-333
     1, 2, 4
     6
     Not found
     
   ##Example of Interactive input
   
   To run the program 
     
     $ bin/parking_lot
   
   ###Input
   Assuming a parking lot with 6 slots, the following commands should be run in sequence by
   
   typing them in at a prompt and should produce output as described below the command:
   
   #####Create parking lot 
   Input : 
     
      $ create_parking_lot 6
         
   Output : 
   
      Created a parking lot with 6 slots
      
   Park 6 cars in the parking lot one by one
   Input for 1st car : 
      
      $ park KA-01-HH-1234 White
      
   Output for 1st car : 
      
      Allocated slot number: 1
      
   Input for 2nd car : 
   
      $ park KA-01-HH-9999 White
      
   Output for 2nd car : 
   
      Allocated slot number: 2
      
   Input for 3rd car : 
   
      $ park KA-01-BB-0001 Black
      
   Output for 3rd car : 
   
      Allocated slot number: 3
      
   Input for 4th car : 
   
      $ park KA-01-HH-7777 Red
      
   Output for 4th car : 
   
      Allocated slot number: 4
      
   Input for 5th car : 
    
      $ park KA-01-HH-2701 Blue
      
   Output for 5th car : 
      
      Allocated slot number: 5
      
   Input for 6th car : 
   
      $ park KA-01-HH-3141 Black
      
   Output for 6th car : 
    
       Allocated slot number: 6
       
   #####Leave the parking lot
   
   Input : 
   
      $ leave 4
      
   Output : 
   
       Slot number 4 is free
       
   #####Status of Parking lot
   
   Input : 
   
      $ status
      
   Output : 
   
      Slot No. Registration No Colour
      1 KA-01-HH-1234 White
      2 KA-01-HH-9999 White
      3 KA-01-BB-0001 Black
      5 KA-01-HH-2701 Blue
      6 KA-01-HH-3141 Black
      
   #####Park car
   
   Input : 
   
      $ park KA-01-P-333 White
      
   Output : 
   
       Allocated slot number: 4
       
   #####Park another car
   
   Input :
      
      $ park DL-12-AA-9999 White
      
   Output : 
   
      Sorry, parking lot is full
      
   #####Get registration numbers of cars based on colour
   
   Input : 
   
      $ registration_numbers_for_cars_with_colour White
      
   Output : 
   
      KA-01-HH-1234, KA-01-HH-9999, KA-01-P-333
      
   #####Get slot numbers for cars based on colour
   
   Input : 
   
      $ slot_numbers_for_cars_with_colour White
      
   Output : 
   
      1, 2, 4
      
   #####Get slot number based on registration number if car found 
   
   Input : 
   
      $ slot_number_for_registration_number KA-01-HH-3141
      
   Output : 
       
       6
       
   #####Get slot number based on registration number if car not found
   
   Input : 
     
     $ slot_number_for_registration_number MH-04-AY-1111
     
   Output : 
    
     Not found
     
   #####Terminate the program 
   
      $ exit    
               
      