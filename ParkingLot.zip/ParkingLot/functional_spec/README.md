####Functional Specification 

#####CreateParkingLot
 Take input as Integer which will be total number of slots we want to have in parking lot and create a parking lot of that number of slots
 
#####Park
Take registration number and colour of car as input and park the car at the slot near to entry and return Sorry, parking lot is full is parking is full.

#####Leave
Make the slot number as empty given in the input and update the next empty slot number where another car can be park

#####GetSlotBasedOnRegistrationNumber
Take registration number of car as input and return the slot number of the car

#####GetSlotsBasedOnColour
Give all the slot numbers of all cars for given colour

#####GetRegistrationNumberBasedOnColour
Return registration numbers of cars based on given colour

#####Status
Give status of the parking lot