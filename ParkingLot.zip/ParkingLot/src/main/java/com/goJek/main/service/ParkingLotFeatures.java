package com.goJek.main.service;

import java.util.List;

public interface ParkingLotFeatures {

    int leave(int slotNumber);

    String park(String registrationNumber,String colour);

    String getSlotBasedOnRegistrationNumber(String registrationNumber);

    List<Integer> getSlotsBasedOnColour(String Colour);

    List<String> getRegistrationNumberBasedOnColour(String Colour);

    void createParkingLot(int totalSlots);

    int status();
}
