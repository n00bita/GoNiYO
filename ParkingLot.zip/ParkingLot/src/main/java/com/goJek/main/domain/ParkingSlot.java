package com.goJek.main.domain;

public class ParkingSlot {
    int floor;

    int slotNo;

    Car car;

    public int getSlotNo() {
        return slotNo;
    }

    public Car getCar() {
        return car;
    }

    public ParkingSlot(int floor, int slotNo, Car car) {
        this.floor = floor;
        this.slotNo = slotNo;
        this.car = car;
    }


}
