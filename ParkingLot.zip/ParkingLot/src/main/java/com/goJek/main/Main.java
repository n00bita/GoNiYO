package com.goJek.main;

import com.goJek.main.service.ParkingLotFeatures;
import com.goJek.main.service.ParkingLotFeaturesImpl;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        if (args.length > 0) {
            Arrays.stream(args).forEach(System.out::println);
            try (FileReader reader = new FileReader(args[0]);
                 BufferedReader bufferedReader = new BufferedReader(reader);
            ) {
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    executeCommand(line);
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            System.exit(0);
        }
        while (true) {
            Scanner input = new Scanner(System.in);
            String line = input.nextLine();
            if ("exit".equals(line)) {
                System.exit(0);
                break;
            }
            executeCommand(line);

        }
    }

    private static void executeCommand(String line) {
        ParkingLotFeatures parkingLot = new ParkingLotFeaturesImpl();
        String[] splittedText = line.split(" ");
        switch (splittedText[0]) {
            case "park":
                parkingLot.park(splittedText[1], splittedText[2]);
                break;
            case "leave":
                parkingLot.leave(Integer.valueOf(splittedText[1]));
                break;
            case "create_parking_lot":
                parkingLot.createParkingLot(Integer.valueOf(splittedText[1]));
                break;
            case "registration_numbers_for_cars_with_colour":
                parkingLot.getRegistrationNumberBasedOnColour(splittedText[1]);
                break;
            case "slot_numbers_for_cars_with_colour":
                parkingLot.getSlotsBasedOnColour(splittedText[1]);
                break;
            case "slot_number_for_registration_number":
                parkingLot.getSlotBasedOnRegistrationNumber(splittedText[1]);
                break;
            case "status":
                parkingLot.status();
                break;
            default:
                break;
        }
    }
}
