package com.goJek.main.domain;

public enum Colour {
    Red,White,Black,Green,Blue
}
