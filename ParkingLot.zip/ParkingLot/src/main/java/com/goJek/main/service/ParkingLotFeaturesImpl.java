package com.goJek.main.service;

import com.goJek.main.domain.Car;
import com.goJek.main.domain.Colour;
import com.goJek.main.domain.ParkingSlot;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.StringJoiner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class ParkingLotFeaturesImpl implements ParkingLotFeatures {
    private static final String SPACE = "       ";
    static ParkingSlot[] parkingSlots;

    public ParkingLotFeaturesImpl() {
    }

    public ParkingLotFeaturesImpl(int totalSlots) {
        this.parkingSlots = new ParkingSlot[totalSlots];
    }

    static int emptySlotNumberClosestToEntry;

    public void createParkingLot(int totalSlots) {
        emptySlotNumberClosestToEntry = 1;
        System.out.println("Created a parking lot with " + totalSlots + " slots");
        new ParkingLotFeaturesImpl(totalSlots);
    }

    @Override
    public int leave(int slotNumber) {
        if (parkingSlots[slotNumber] == null) {
            System.out.println("Slot number is empty");
            return -1;
        }
        parkingSlots[slotNumber - 1] = null;
        System.out.println("Slot number " + slotNumber + " is free");
        if (slotNumber < emptySlotNumberClosestToEntry) {
            emptySlotNumberClosestToEntry = slotNumber;  //update the empty slot
        }
        return slotNumber;
    }

    int createParkingSlot(Car car) {
        final int LAST_SLOT_NUMBER = parkingSlots.length;
        //return -1 if the parking is full
        if (emptySlotNumberClosestToEntry > LAST_SLOT_NUMBER) {
            return -1;
        }
        int slotNumber = emptySlotNumberClosestToEntry;
        ParkingSlot parkingSlot = new ParkingSlot(1, emptySlotNumberClosestToEntry, car);
        parkingSlots[slotNumber - 1] = parkingSlot;
        findNextEmptySlotNumber();
        return slotNumber;
    }

    private static void findNextEmptySlotNumber() {
        final int LAST_SLOT_NUMBER = parkingSlots.length;
        if (emptySlotNumberClosestToEntry == LAST_SLOT_NUMBER) {
            emptySlotNumberClosestToEntry++;
        } else {
            //update next empty slot
            for (int currentSlot = emptySlotNumberClosestToEntry + 1; currentSlot <= LAST_SLOT_NUMBER; currentSlot++) {
                if (parkingSlots[currentSlot - 1] == null) {
                    emptySlotNumberClosestToEntry = currentSlot;
                    break;
                }
                //update emptySlotNumberClosestToEntry if parking is full
                if (currentSlot == LAST_SLOT_NUMBER) {
                    emptySlotNumberClosestToEntry = LAST_SLOT_NUMBER + 1;
                    break;
                }
            }
        }
    }

    @Override
    public String park(String registrationNumber, String colour) {
        Car car = new Car(Colour.valueOf(colour), registrationNumber);
        final int slotNumber = createParkingSlot(car);
        String result = slotNumber == -1 ? "Sorry, parking lot is full" : "Allocated slot number: " + slotNumber;
        System.out.println(result);
        return result;
    }

    @Override
    public String getSlotBasedOnRegistrationNumber(String registrationNumber) {
        for (int i = 0; i < parkingSlots.length; i++) {
            if (parkingSlots[i] != null) {
                if (parkingSlots[i].getCar().getRegistrationNumber().equals(registrationNumber)) {
                    System.out.println(String.valueOf(i + 1));
                    return String.valueOf(i + 1);
                }
            }
        }
        System.out.println("Not found");
        return "Not found";
    }

    @Override
    public List<Integer> getSlotsBasedOnColour(String colourStr) {
        Colour colour = Colour.valueOf(colourStr);
        List<Integer> list = new ArrayList<>();
        String output = Stream.of(parkingSlots)
                .filter(Objects::nonNull)
                .filter(x -> colour.equals(x.getCar().getColour()))
                .peek(x -> list.add(x.getSlotNo()))
                .map(x -> String.valueOf(x.getSlotNo()))
                .collect(Collectors.joining(", "));
        System.out.println(output);
        return list;
    }

    @Override
    public List<String> getRegistrationNumberBasedOnColour(String colourStr) {
        Colour colour = Colour.valueOf(colourStr);
        List<String> registrationNumbersList = Stream.of(parkingSlots)
                .filter(Objects::nonNull)
                .filter(x -> colour.equals(x.getCar().getColour()))
                .map(x -> x.getCar().getRegistrationNumber())
                .collect(Collectors.toList());
        StringJoiner builder = new StringJoiner(", ");
        registrationNumbersList.forEach(x -> builder.add(String.valueOf(x)));
        System.out.println(builder.toString());
        return registrationNumbersList;
    }

    @Override
    public int status() {
        int numberOfOccupiedSlots = 0;
        System.out.println(new StringJoiner(SPACE).add("Slot No.").add("Registration No").add("Colour").toString());
        for (int i = 0; i < parkingSlots.length; i++) {
            if (parkingSlots[i] != null) {
                numberOfOccupiedSlots++;
                String row = new StringJoiner(SPACE)
                        .add(String.valueOf(parkingSlots[i].getSlotNo()))
                        .add("")
                        .add(parkingSlots[i].getCar().getRegistrationNumber())
                        .add(String.valueOf(parkingSlots[i].getCar().getColour()))
                        .toString();
                System.out.println(row);
            }
        }
        return numberOfOccupiedSlots;
    }
}
