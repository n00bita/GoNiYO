package com.goJek.main.domain;

public class Car {

    Colour colour;
    String registrationNumber;

    public Colour getColour() {
        return colour;
    }

    public void setColour(Colour colour) {
        this.colour = colour;
    }

    public String getRegistrationNumber() {
        return registrationNumber;
    }

    public Car(Colour colour, String registrationNumber){
        this.colour = colour;
        this.registrationNumber = registrationNumber;
    }
}
