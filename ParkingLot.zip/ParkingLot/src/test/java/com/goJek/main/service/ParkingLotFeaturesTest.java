package com.goJek.main.service;

import com.goJek.main.domain.Colour;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class ParkingLotFeaturesTest {
    ParkingLotFeatures parkingLotFeatures = new ParkingLotFeaturesImpl();

    @Before
    public void setUp(){
        int TOTAL_NUMER_OF_SLOTS = 5;
        parkingLotFeatures.createParkingLot(TOTAL_NUMER_OF_SLOTS);
    }


    @Test
    public void park_whenParkingLotIsEmpty(){
        String result =  parkingLotFeatures.park("KA-01-HH-1234", Colour.Black.toString());
        String response=  parkingLotFeatures.park("KA-01-BB-1222", Colour.Blue.toString());
        Assert.assertEquals("Allocated slot number: 1", result);
        Assert.assertEquals("Allocated slot number: 2",response);
    }

    @Test
    public void park_whenParkingLotIsFull(){
        parkingLotFeatures.park("KA-01-HH-1234", Colour.Black.toString());
        parkingLotFeatures.park("KA-01-BB-1222", Colour.Blue.toString());
        parkingLotFeatures.park("KA-01-BB-1221", Colour.Blue.toString());
        parkingLotFeatures.park("KA-01-BB-1121", Colour.White.toString());
        parkingLotFeatures.park("KA-01-BB-1021", Colour.Black.toString());
        String result =  parkingLotFeatures.park("KA-01-BB-1211", Colour.White.toString());
        Assert.assertEquals("Sorry, parking lot is full", result);

    }

    @Test
    public void leave_slot1(){
        parkingLotFeatures.park("KA-01-HH-1234", Colour.Black.toString());
        parkingLotFeatures.park("KA-01-BB-1222", Colour.Blue.toString());
       int result =  parkingLotFeatures.leave(1);
       Assert.assertEquals(1, result);
    }

    @Test
    public void testBoundary(){
        parkingLotFeatures.createParkingLot(3);
        parkingLotFeatures.park("KA-01-HH-1234", Colour.Black.toString());
        parkingLotFeatures.park("KA-01-BB-1222", Colour.Blue.toString());
        parkingLotFeatures.park("KA-01-BB-1222", Colour.Blue.toString());
        parkingLotFeatures.leave(2);
        parkingLotFeatures.status();
        parkingLotFeatures.park("KA-01-BB-1225", Colour.Blue.toString());
        parkingLotFeatures.park("KA-01-BB-1226", Colour.Blue.toString());
    }


    @Test
    public void getSlotBasedOnRegistrationNumber_WhenCarFound(){
        parkingLotFeatures.park("KA-01-HH-1234", Colour.Black.toString());
        String result = parkingLotFeatures.getSlotBasedOnRegistrationNumber("KA-01-HH-1234");
        Assert.assertEquals("1", result);
    }

    @Test
    public void getSlotBasedOnRegistrationNumber_WhenCarNoFound(){
        String result = parkingLotFeatures.getSlotBasedOnRegistrationNumber("KA-01-HH-1234");
        Assert.assertEquals("Not found", result);
    }

    @Test
    public void getSlotBasedOnColour(){
        parkingLotFeatures.park("KA-01-HH-1234", Colour.White.toString());
        List<Integer> result = parkingLotFeatures.getSlotsBasedOnColour("White");
        Assert.assertTrue( result.get(0).equals(1));
    }

    @Test
    public void getSlotBasedOnColour_EmptyParkingSlot(){
        List<Integer> result = parkingLotFeatures.getSlotsBasedOnColour("White");
        Assert.assertTrue( result.isEmpty());
    }

    @Test
    public void getRegistrationNumberBasedOnColour_NoCarWithSameColour(){
       List<String> result = parkingLotFeatures.getRegistrationNumberBasedOnColour("White");
        Assert.assertTrue( result.isEmpty());
    }

    @Test
    public void getRegistrationNumberBasedOnColour_CarWithSameColourFound(){
        parkingLotFeatures.park("KA-01-HH-1234", Colour.Black.toString());
        List<String> result = parkingLotFeatures.getRegistrationNumberBasedOnColour("Black");
        Assert.assertTrue( result.get(0).equals("KA-01-HH-1234"));
    }


        @Test
        public void status(){
            parkingLotFeatures.park("KA-01-HH-1234", Colour.Black.toString());
            parkingLotFeatures.park("KA-01-HH-1211", Colour.Black.toString());
            int result = parkingLotFeatures.status();
            Assert.assertEquals(2, result);
        }
}
